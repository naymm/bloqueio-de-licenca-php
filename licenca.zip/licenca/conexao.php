<?php
    $conexao = new mysqli('localhost', 'root', '', 'licenca') or die(mysqli_error($conexao));
?>